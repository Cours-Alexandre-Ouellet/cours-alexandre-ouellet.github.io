from geometrie import distance as geo_dist, aire_carre as geo_aire

print(geo_dist((0, 1), (0, 2)))
print(geo_aire((0, 1), (0, 2)))